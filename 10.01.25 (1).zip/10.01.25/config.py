#Config бота

CRYPTOTOKEN = '321397:AAM9FlxMVnySt2XWd0WSQIveeFCuIFXwanF' # брать у @send
TOKEN = '8026017023:AAGnjQU6NC3BB9lYZeSKgDS5UrVKJGWz3cA' # токен брать у botfather
DIRECTORY = 'kosSESSjj' # не трогать
photo_path = 'Doxbin.png' # ссылка на фото
ADMIN = 6872254890 # айди админа брать у getmyid
SUPPORT = 't.me/fdfdfsdfsfdssdf' # ссылка на тех.поддержкуц
API_ID = 26484445 # не трогать
API_HASH = '1181da6642bfbd3bd7275754d3f16a30' # не трогать
